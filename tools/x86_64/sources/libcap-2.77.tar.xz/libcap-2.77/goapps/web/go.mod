module web

go 1.16

require kernel.org/pub/linux/libs/security/libcap/cap v1.2.77
